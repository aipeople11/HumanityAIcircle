Use this as the **master one-shot prompt**. It is intentionally written so that whenever you provide your latest website build, the agent must **first audit it, benchmark it, think like an independent potential member, and only then redesign/build it**.

---

# HUMANITY AI CIRCLE — MASTER ONE-SHOT WEBSITE PROMPT V4

> You are acting simultaneously as a **senior brand strategist, Ogilvy-style marketing consultant, community product strategist, UX/UI director, conversion specialist, research/evidence designer, and independent potential member of Humanity AI Circle**.
>
> I will provide you with the **latest build of the Humanity AI Circle website**. Do not blindly redesign it and do not throw away good work.
>
> Your first responsibility is to **inspect the complete existing website, all pages, navigation, copy, visuals, links, research sections, CTAs, mobile structure, and user journey**.
>
> Then independently evaluate it before making changes.

---

# 0. STRATEGIC HIERARCHY — DO NOT LOSE THIS

The website must preserve seven distinct layers of the Humanity AI Circle proposition:

```text
CONTEXT
AI is changing how we work, learn and live.
We are in a transition period.

FRONT DOOR
Don't figure out AI alone.

HUMANITY PRINCIPLE
People come first.
AI should support human capability, not replace human connection,
judgment, responsibility or agency.

MEMBER VALUE
Ask → Connect → Learn → Articulate → Try → Validate → Improve.

PRACTICAL PRINCIPLE
Outcome first. Tool second. Brand last.
Use the simplest reliable AI approach that gets the job done.

DIFFERENTIATOR
Real people test real workflows, compare outcomes,
and turn useful experience into increasingly structured evidence.

LONG-TERM ASSET
A trusted evidence network showing what AI workflows work,
for whom, for which task, under what conditions,
what they cost in time/tokens/rework,
and what human checks remain necessary.
```

The website should **lead emotionally with the human transition and human problem**, then progressively reveal practical learning, responsible use and the evidence model.

Do not turn the homepage into an evidence/research product pitch.

Do not reduce the long-term vision to a generic support community, generic AI training site, tool directory or fear-based news site.

The human need brings people in. Practical capability keeps them useful. Evidence creates long-term strategic value.

---

## 1. FIRST: AUDIT THE CURRENT BUILD

Evaluate the current website as if you had never heard of Humanity AI Circle before.

Ask yourself:

> **Within 5–10 seconds, do I understand why this community exists?**
>
> **Do I immediately understand why I personally should join?**
>
> **Does it address a problem I genuinely experience with AI?**
>
> **Do I trust it?**
>
> **Does it look active and useful?**
>
> **Can I quickly understand what happens after I join?**
>
> **Can I see evidence rather than marketing claims?**
>
> **Do I know where to click next?**
>
> **Would I actually join the WhatsApp community? Why or why not?**

Do not evaluate only aesthetics.

Evaluate the complete **potential-member decision journey**.

---

# 2. BENCHMARK THE WEBSITE

Benchmark the existing website from **0–10** on:

```text
FIRST-5-SECONDS CLARITY

EMOTIONAL CONNECTION

WHY-JOIN CLARITY

PAIN-POINT RELEVANCE

COMMUNITY TRUST

DIFFERENTIATION

VISUAL STORYTELLING

TEXT SIMPLICITY

RESEARCH CREDIBILITY

DATA VISUALIZATION

SOURCE TRANSPARENCY

COMMUNITY ACTIVITY SIGNAL

NAVIGATION

PAGE DEPTH

CTA STRENGTH

MOBILE READINESS

SHAREABILITY

MEMBER CONVERSION POTENTIAL

TRANSITION / WHY-NOW RELEVANCE

HUMAN AGENCY / PEOPLE-FIRST CLARITY

TOOL-OVERLOAD SOLUTION

OUTCOME-FIRST DIFFERENTIATION

TASK ARTICULATION VALUE

AI EFFICIENCY / REWORK / TOKEN AWARENESS

TRUST / RESPONSIBLE AI

HUMAN CONTROL / AUTONOMY BOUNDARIES

GLOBAL CURIOSITY COVERAGE

FOUNDER CREDIBILITY

CURRENT-ISSUE / NEWS RELEVANCE
```

For every weak area, identify:

```text
WHAT EXISTS NOW
↓
WHAT IS WRONG
↓
WHY A VISITOR MAY DROP
↓
WHAT SHOULD REPLACE IT
```

Do not give high scores merely because the site looks attractive.

Judge it like an independent marketer whose reputation depends on conversion.

---

# 2A. THE TRANSITION STORY — WHY NOW

Humanity AI Circle should explain the current moment through a simple historical transition story.

Do not overclaim that technology eras happened in clean, separate phases. Use the timeline as an accessible storytelling device:

```text
PERSONAL COMPUTING
Work became digital
        ↓
INTERNET
People and information became connected
        ↓
MOBILE + CLOUD
Work became available almost anywhere
        ↓
AI
How work, learning, creation and decisions get done is changing
        ↓
YOU
Learn • Adapt • Stay capable • Stay in control
```

The public story should be simple:

# **AI is changing how we work, learn and live.**

Supporting transition line:

# **Every major technology transition required people to learn and adapt. This one will too.**

The website should communicate that transition is not only about adopting tools. It includes:

- upskilling,
- mindset change,
- overcoming fear and uncertainty,
- learning how to articulate a task clearly,
- learning when AI is useful and when it is not,
- validating outputs,
- protecting human judgment and responsibility,
- learning with other people rather than adapting in isolation.

Do not present AI adoption as inevitable progress or as guaranteed job loss. Present it as a period of change that different people and professions will experience differently.

---

# 2B. HUMANITY PRINCIPLE — AI SUPPORTS PEOPLE

Humanity AI Circle is a **people-connect community**, not an AI-companionship product.

The central belief is:

# **AI should support people. People should not become subordinate to AI.**

A warmer public version is:

# **AI can be a companion to human capability. It should never replace human connection, judgment or agency.**

Use "companion" carefully. The website must never encourage emotional dependency on AI or imply that AI is a substitute for friends, family, teachers, colleagues, professionals or community.

The community should reinforce:

```text
AI CAN HELP
Research • Draft • Analyze • Explore • Automate

PEOPLE STILL OWN
Goals • Values • Judgment • Approval • Relationships • Consequences
```

Signature question:

# **What should AI help with — and what should stay human?**

Additional principles:

- Use AI to extend human capability, not to outsource human responsibility.
- Learn from AI without becoming dependent on it.
- Keep meaningful human relationships human.
- Treat AI output as input to judgment, not automatic truth.
- Preserve the ability to think, question, decide and disagree.

---

# 2C. GLOBAL AI CURIOSITY MAP

The website is global in vision. It should recognize that people are curious, excited or concerned about AI for different reasons.

Organize these concerns into five simple universal themes rather than exposing a long unstructured topic list.

```text
1. HOW WILL AI CHANGE ME?
Jobs • Career • Skills • Upskilling • Mindset • Transition

2. HOW SHOULD I LEARN AND USE IT?
Learning • Teaching • Articulation • Tools • Workflows • Productivity • Cost

3. CAN I TRUST IT?
Accuracy • Misinformation • Deepfakes • Privacy • Scams • Health

4. WHAT SHOULD STAY HUMAN?
Judgment • Creativity • Relationships • Loneliness • Dependence • Responsibility

5. HOW MUCH CONTROL SHOULD AI HAVE?
Agents • Autonomy • Permissions • Approvals • Limits • Guardrails • Human override
```

Potential visitor hooks include:

- Will AI change my job — and what should I do now?
- What should I learn before my work changes?
- Is AI helping me learn — or just doing the work for me?
- My child is using AI. How should I think about it?
- Where can AI genuinely save me time?
- Do I really need another AI tool?
- How do I know whether this answer is true?
- Is this voice, image or message real?
- What should I never give an AI system?
- When should I talk to AI — and when do I need another person?
- When does AI assistance become AI dependence?
- What happens when AI stops answering and starts acting?
- What decisions should always require a human?
- What should an autonomous AI be allowed to do without asking?
- If AI helps create something, who owns it?
- Can a small business use AI effectively without buying every tool?
- Does AI work equally well for my language and context?

The homepage should not show every hook at once. Use a small rotating/curated set and let deeper pages carry the breadth.

---

# 2D. RESPONSIBLE AI, HUMAN CONTROL AND AUTONOMY

Humanity AI Circle should make responsible use practical rather than abstract.

Public question:

# **Just because AI can do something, should it do it alone?**

For autonomous/agentic AI, teach a simple boundary model:

```text
BEFORE AI ACTS

WHAT CAN IT SEE?
        ↓
WHAT CAN IT CHANGE?
        ↓
WHAT CAN IT SEND?
        ↓
WHAT CAN IT SPEND?
        ↓
WHAT REQUIRES APPROVAL?
        ↓
WHEN MUST IT STOP?
        ↓
WHO IS ACCOUNTABLE?
```

Core principle:

# **Capability does not automatically mean authority.**

The community should normalize:

- explicit permission boundaries,
- minimum necessary access,
- approval checkpoints for consequential actions,
- spending/transaction limits,
- privacy and data boundaries,
- logging and traceability where appropriate,
- clear stop/escalation conditions,
- human override,
- accountability for outcomes.

Do not imply that one universal guardrail model fits every situation. The right boundary depends on task, risk, stakes and context.

---

# 3. CORE HUMAN PROBLEM

The central insight of Humanity AI Circle is:

## **Don't figure out AI alone.**

People are already experimenting with AI.

The problem is that when they get stuck, there is often **nobody obvious to ask**.

In normal life:

```text
HOME
Problem → Parent / family

WORK
Problem → Manager / colleague / expert

HEALTH
Problem → Doctor

EDUCATION
Problem → Teacher

AI
Problem → ???
```

AI is changing so quickly that almost everyone is still learning.

A person may wonder:

```text
Am I using this correctly?

Is this output actually good?

Which tool should I use?

Why did this fail?

Can I trust this answer?

Could there be a better workflow?

Am I wasting time?

How are other people doing this?

Is my job changing?

What should I learn?

Can somebody brainstorm this with me?

Who will actually listen to my problem?
```

People can feel uncomfortable asking coworkers.

Managers are busy.

Experts may not have time.

Online content gives answers but rarely listens to the individual's problem.

Humanity AI Circle should become:

# **The place you can go when you are stuck with AI.**

---

# 4. THE EMOTIONAL PROMISE

The website should make the visitor feel:

> **“I have somewhere to ask.”**

> **“Someone will listen.”**

> **“Other people are facing the same problems.”**

> **“I don't need to pretend I already understand AI.”**

> **“I can discuss what I am doing and get another perspective.”**

> **“I can learn from people experimenting just like me.”**

> **“I can move forward with more confidence.”**

The community must never promise that it will always produce a perfect answer.

Its promise is:

# **A place to ask.  
People who listen.  
Ideas to try.  
Evidence to learn from.  
Confidence to move forward.**

---

# 5. HOMEPAGE JOB

The homepage must NOT try to explain the entire organization.

Its job is to make the visitor think:

# **“This community understands my problem. I should join.”**

Within the first screen communicate:

## DON'T FIGURE OUT AI ALONE.

Supporting message:

> **When AI feels confusing, uncertain or overwhelming, bring your question here. Learn from real people, discuss what works and move forward with more confidence.**

Primary CTA:

> **Join the Community**

Supporting label where appropriate:

> **Continue on WhatsApp ↗**

Secondary CTA:

> **See How It Works**

WhatsApp is the current community destination, not the permanent definition of the brand. The site architecture must allow the join destination to change later without requiring the brand proposition to be rewritten.

---

# 6. SHOW PAIN BEFORE FEATURES

Very early on the homepage show:

## You may be here because...

Use mostly **icons + 2–5 words**, not repetitive human illustrations.

Examples:

```text
💼
MY JOB IS CHANGING

🧰
TOO MANY AI TOOLS

❓
IS THIS OUTPUT RIGHT?

🧭
I DON'T KNOW WHAT TO LEARN

💡
I HAVE AN IDEA

💬
I NEED FEEDBACK

🧩
I'M STUCK

🤝
I NEED SOMEONE TO ASK
```

Then:

# **You don't have to figure it out alone.**

---

# 6A. OUTCOME FIRST — TOOL SECOND — BRAND LAST

The AI market is flooded with tools, models, subscriptions, agents and competing claims. Humanity AI Circle should not add to that confusion.

The community begins with:

# **What are you trying to achieve?**

Not:

> Which AI brand do you prefer?

Use this practical flow:

```text
OUTCOME
↓
TASK
↓
CONTEXT + CONSTRAINTS
↓
SIMPLEST VIABLE WORKFLOW
↓
RIGHT TOOL / MODEL
↓
VALIDATE OUTPUT
↓
MEASURE REWORK / TIME / COST
↓
REUSE WHAT WORKS
```

Core line:

# **Outcome first. Tool second. Brand last.**

Do not imply that the most expensive, newest or most powerful model is automatically the right choice.

---

# 6B. TASK ARTICULATION — BIGGER THAN PROMPTING

Do not position Humanity AI Circle merely as a prompt-engineering community.

Prompt syntax will change. The durable skill is **task articulation**.

Teach people to clarify:

```text
WHAT DO I NEED?
↓
WHAT CONTEXT MATTERS?
↓
WHAT ARE THE CONSTRAINTS?
↓
WHAT DOES GOOD LOOK LIKE?
↓
WHAT SHOULD AI DO?
↓
WHAT MUST A HUMAN CHECK?
```

Public line:

# **Learn to ask AI for the work you actually need.**

The community may help people turn vague requests into clear tasks, reusable instructions and practical workflows.

---

# 6C. EFFICIENT AI USE

Humanity AI Circle should not encourage maximum AI usage. It should encourage **effective AI usage**.

Help people reduce:

- unnecessary tool switching,
- repeated prompting,
- oversized context,
- needless premium-model usage,
- token/cost waste,
- unnecessary retries,
- duplicated work,
- human rework caused by weak outputs.

Measure success through the overall outcome, including human correction.

Public concept:

# **Use AI with less waste and more purpose.**

---

# 7. SHOW BENEFITS, NOT PLATFORM FEATURES

Do not lead with:

```text
We have sessions.
We have groups.
We have mentors.
```

Instead communicate what the member gets:

### CLARITY
Know what to try next.

### CONFIDENCE
Understand whether your approach makes sense.

### PERSPECTIVE
Hear how other people approach the same problem.

### SUPPORT
Have somewhere to ask when you get stuck.

### CONNECTION
Meet people who understand your challenge.

### LEARNING
Discover practical workflows and real examples.

### OPPORTUNITY
Turn learning into progress, projects and possibilities.

---

# 8. SHOW TRANSFORMATION

Marketing should show **before → after**.

For example:

```text
"I don't know where to begin."
        ↓
"I know my next step."
```

```text
"Everyone recommends a different AI tool."
        ↓
"I understand what works for my task."
```

```text
"I'm not sure my AI output is correct."
        ↓
"I got another perspective and know what to check."
```

```text
"I have an idea but I'm stuck."
        ↓
"I found people who helped me think it through."
```

```text
"I'm worried about AI changing my work."
        ↓
"I'm learning how to work with it."
```

Use diagrams, icons, arrows and cards rather than paragraphs.

---

# 9. VISUAL RULE

Target approximately:

```text
70–80% VISUAL COMMUNICATION
20–30% TEXT
```

But **visual does not mean filling every card with people**.

Human illustrations should be reserved for:

- hero storytelling
- community moments
- genuine member stories
- selected major emotional moments

For most secondary sections use:

- icons
- symbols
- short words
- diagrams
- flow lines
- numbers
- cards
- badges
- micro charts
- timelines
- progress indicators
- small illustrations
- before/after graphics

Avoid visual repetition of a boy/girl sitting with a laptop in every card.

---

# 10. DESIGN SYSTEM

Maintain the established Humanity AI Circle character:

- warm cream / subtle grid background
- thick dark outlines
- rounded cards
- offset shadows
- bright friendly accent colors
- playful but credible
- modern editorial typography
- compact modules
- human warmth
- highly scannable
- responsive/mobile friendly

It should feel like a world-class marketing organization designed it.

Think:

> **brand campaign + community platform + editorial storytelling**

Not:

> corporate SaaS dashboard.

Not:

> consulting report.

Not:

> one giant infographic.

---

# 11. MULTI-PAGE WEBSITE

The website must be a genuine **multi-page experience**.

Do not put everything on `index.html`.

Recommended top-level architecture:

```text
HOME
WHY JOIN
HOW IT WORKS
EVIDENCE
COMMUNITY
ABOUT

[JOIN COMMUNITY]
```

Use secondary depth rather than overcrowding the main navigation:

```text
COMMUNITY
├── Sessions
└── Stories

EVIDENCE
└── Research
```

Keep **Join Community** visually distinct as the primary navigation CTA.

You may add/remove pages if independent evaluation shows a better structure.

Every main navigation item must lead somewhere meaningful.

Do not leave decorative dead links.

---

# 12. HOME PAGE

Keep the homepage concise.

The homepage should now connect four stories in order:

```text
TRANSITION
AI is changing how we work, learn and live
↓
HUMAN NEED
Don't figure out AI alone
↓
PRACTICAL CAPABILITY
Learn • Articulate • Choose • Try • Validate • Improve
↓
TRUST + EVIDENCE
Test • Compare • Repeat • Share what we learn
```

Do not make fear the hero. Show uncertainty honestly, then move quickly toward agency, learning, connection and responsible action.

Suggested journey:

```text
1. HERO
   AI is changing how we work, learn and live.
   Don't figure it out alone.

2. THE TRANSITION
   PC → Internet → Mobile/Cloud → AI → You

3. WHAT ARE YOU TRYING TO FIGURE OUT?
   jobs / skills / tools / trust / learning / autonomy / human connection

4. OUTCOME FIRST
   You do not need every tool. Start with what you need to accomplish.

5. LEARN TO WORK WITH AI
   Understand → Articulate → Choose → Try → Validate → Improve

6. PEOPLE CONNECT
   Peer → Practitioner → Domain perspective → Community

7. RESPONSIBLE USE / HUMAN CONTROL
   What should AI help with? What should stay human?

8. TEST, COMPARE AND LEARN
   quality / time / cost-tokens / rework / reliability / risk

9. AI TRANSITION PULSE
   3–4 current source-linked questions/data points

10. JOIN CTA
    Bring your real AI question / problem.
```

Do not explain every detail here.

Use the other pages for depth.

---

# 13. WHY JOIN PAGE

This page answers only:

# **“What's in this community for me?”**

Organize by pains and outcomes.

Allow visitors to recognize themselves.

Potential paths:

```text
I'M NEW TO AI

I USE AI BUT FEEL UNSURE

MY JOB IS CHANGING

I NEED A BETTER WORKFLOW

I HAVE AN IDEA

I NEED FEEDBACK

I WANT TO LEARN

I WANT TO HELP OTHERS
```

Clicking a path should reveal relevant examples, community activities or evidence.

---

# 14. HOW IT WORKS PAGE

Keep it extremely visual.

Primary loop:

```text
ASK
↓
DISCUSS
↓
LEARN
↓
TRY
↓
SHARE
↓
IMPROVE
```

Second layer:

```text
REAL PROBLEM
↓
REAL USERS
↓
REAL WORKFLOW
↓
FEEDBACK
↓
BETTER OUTCOME
```

Explain the community without making users read a manifesto.

---

# 15. COMMUNITY PAGE

Make the community feel alive.

Show roles such as:

```text
EXPLORER
I have a question.

TESTER
I tried something.

CONTRIBUTOR
I share what happened.

EXPERT
I add domain perspective.

MENTOR
I help others learn.

BUILDER
I help solve problems.
```

Also visually communicate:

```text
LEARNER ↔ EXPERIENCED USER

IDEA ↔ BUILDER

QUESTION ↔ COMMUNITY

PROBLEM ↔ EXPERIENCE

BEGINNER ↔ MENTOR
```

But do not imply guaranteed matching.

---

# 15A. COMMUNITY TESTING AND INDEPENDENT COMPARISON

When people ask "Which tool should I use?", the community should avoid unsupported brand recommendations.

Where practical, convert the question into an outcome test:

```text
REAL NEED
↓
DEFINE SUCCESS
↓
SHORTLIST TOOLS / WORKFLOWS
↓
RUN COMPARABLE TESTS
↓
COMPARE
QUALITY • TIME • COST/TOKENS • REWORK • RELIABILITY • RISK
↓
REPEAT WHERE USEFUL
↓
SHARE THE CONDITIONS AND FINDINGS
```

The goal is **independent guidance**, not a universal winner.

Do not publish a "best AI tool" without context.

Prefer:

> For this task, for this user/context, under these constraints, these approaches produced these outcomes and trade-offs.

---

# 16. EVIDENCE PAGE

This is one major differentiator.

Position:

# **Opinions are useful. Evidence is better.**

Do not turn this into an academic report.

Use visual evidence cards.

Show the hierarchy:

```text
EXPERIENCE
↓
DOCUMENTED
↓
MEASURED
↓
CORROBORATED
↓
REPEATED
```

Explain:

> One successful attempt is useful experience.

> When results are documented and independently repeated by other people, confidence in the pattern can become stronger.

The website must never imply that a repeated result is guaranteed, universally valid, or formally certified unless an explicit methodology supports that claim.

Show sample evidence cards containing:

```text
TASK

WHO TESTED IT

BASELINE

WORKFLOW

AI TOOL / MODEL / VERSION

OUTCOME

TIME

QUALITY

HUMAN CORRECTION

WHAT FAILED

NUMBER OF RUNS

REPEATABILITY

LAST TESTED

SOURCE / METHODOLOGY
```

Never fabricate community results.

If real results do not yet exist, clearly mark UI examples:

> **Illustrative example — not yet community evidence.**

---

# 16A. EVIDENCE TRUTH RULE

The website must visibly distinguish between different types of claims and evidence.

Use the following categories consistently:

### EXTERNAL RESEARCH
Published evidence from third-party sources.

### COMMUNITY EXPERIENCE
A member describing what happened to them.

### COMMUNITY EVIDENCE
Structured results collected through Humanity AI Circle.

### REPEATED EVIDENCE
The same task or workflow tested independently by multiple participants with comparable context.

### ILLUSTRATIVE EXAMPLE
A hypothetical UI, card, workflow or example used only to explain the concept. It is not real community evidence.

Rules:

```text
NEVER PRESENT AN ILLUSTRATIVE EXAMPLE AS REAL EVIDENCE.

NEVER PRESENT ONE MEMBER'S EXPERIENCE AS A GENERAL CONCLUSION.

NEVER PRESENT EXTERNAL RESEARCH AS HUMANITY AI CIRCLE'S OWN FINDING.

NEVER PRESENT REPEATED RESULTS AS A GUARANTEE.

ALWAYS SHOW SOURCE / SAMPLE / CONTEXT / LAST TESTED WHERE RELEVANT.
```

The visual design should make the category understandable without requiring users to read methodology notes.

---

# 16B. AI TRANSITION PULSE — NEWS → HUMAN QUESTION

The website may use current AI developments to stay relevant, but Humanity AI Circle is **not an AI news site**.

Use news as a human-question generator:

```text
CURRENT DEVELOPMENT / DATA
↓
WHAT DOES IT MEAN FOR A PERSON?
↓
WHAT QUESTION SHOULD THEY ASK?
↓
WHAT CAN THE COMMUNITY DISCUSS / TEST / VERIFY?
```

Examples:

```text
JOB-CHANGE NEWS
→ What should I learn now?

NEW TOOL LAUNCH
→ Does this actually improve my task?

AI PRODUCTIVITY CLAIM
→ Was time saved after review and correction?

DEEPFAKE / FRAUD NEWS
→ How can I verify what I am seeing?

AI COMPANION / LONELINESS NEWS
→ When is AI useful conversation, and when do I need another human?

AGENT / AUTONOMY NEWS
→ What should this AI be allowed to do without approval?

SAFETY / RESPONSIBLE-AI NEWS
→ Where should the human checkpoint be?
```

Rule:

# **Use news to create useful conversations, not fear.**

All current statistics and news claims must be dated and source-linked.

---

# 16C. FOUNDER / ORIGIN CREDIBILITY

The website should explain why Humanity AI Circle was created without turning the brand into a founder-centric personal profile.

Suggested framing:

> The community was started by people with more than a decade of experience across technology and transformation, including hands-on AI research and implementation. A recurring problem kept appearing: people were gaining access to more AI tools, but not necessarily more clarity about what to use, how to use it effectively, or whether it actually improved the outcome. Humanity AI Circle exists to help close that gap through people, practical learning and increasingly independent real-world evidence.

Only publish founder credentials that can be truthfully supported.

---

# 17. RESEARCH PAGE

Global research is used to explain:

# **Why Humanity AI Circle needs to exist.**

Do NOT paste research reports.

Create visual storytelling.

Every data point follows:

```text
BIG NUMBER

WHAT IT MEANS FOR A PERSON

WHY IT MATTERS HERE

SOURCE ↗
```

Use credible primary/authoritative research where possible.

Every research claim must have a working clickable source.

---

# 18. DATA VISUALIZATION

Use visualization only where it helps understanding.

Good candidates:

### AI Usage vs AI Nervousness
Show that adoption does not automatically create confidence.

### AI Adoption vs Outcome Measurement
Show that usage can move faster than proof.

### Experience → Evidence
Visual maturity path.

### Baseline vs AI Outcome
For future measured community tests.

### Human Correction
Show how much human work remains after an AI result.

### Repeatability
Show how often the same workflow succeeds across users/runs.

Charts should be:

- small
- friendly
- colorful
- interactive where appropriate
- source-linked
- understandable without statistical expertise

Avoid large formal dashboard pages.

---

# 19. CLICKABLE EXPERIENCE

Think like an actual visitor.

Where useful, cards should be clickable.

Examples:

```text
"Is this AI output right?"
→ relevant discussion/example

"Which AI tool should I use?"
→ outcome-first guidance

"I'm worried about my job."
→ AI & My Job stories

"I need help."
→ community / WhatsApp

"Show me the evidence."
→ evidence page

"Where did this number come from?"
→ original research source
```

Avoid dead decorative cards.

Every interaction should have a reason.

---

# 20. RESEARCH/EVIDENCE BENCHMARK

For every research section evaluate:

```text
IS THE NUMBER CURRENT?

IS THE SOURCE CREDIBLE?

IS THE SOURCE CLICKABLE?

DOES THE GRAPH REPRESENT THE DATA CORRECTLY?

IS THE HUMAN MEANING CLEAR?

DOES IT HELP EXPLAIN WHY THIS COMMUNITY EXISTS?

DOES IT SUPPORT RATHER THAN OVERWHELM THE STORY?
```

Never use a statistic simply because it looks impressive.

---

# 21. COMMUNITY ACTIVITY

The visitor must understand what actually happens after joining.

Examples:

```text
ASK A QUESTION

JOIN A 30-MINUTE DISCUSSION

TEST AN AI WORKFLOW

SHARE WHAT HAPPENED

GET COMMUNITY FEEDBACK

LISTEN TO A MEMBER STORY

HELP ANOTHER MEMBER

JOIN A REPLICATION CHALLENGE
```

Show activity rather than just saying:

> "We are a vibrant community."

---

# 22. SESSIONS PAGE

Use short, useful formats:

```text
30-MINUTE AI CLINIC

BRING YOUR AI PROBLEM

WHAT WORKED FOR ME

TOOL / WORKFLOW TEST

ASK A PRACTITIONER

COMMUNITY BRAINSTORM

AI & MY JOB

WHAT SHOULD STAY HUMAN?
```

Do not invent future dates/events.

Only display scheduled events when there are actual dates.

---

# 23. STORIES PAGE

Human stories should create emotional proof.

Each real story eventually contains:

```text
PERSON

THEIR QUESTION / PROBLEM

WHAT THEY TRIED

WHAT THEY LEARNED

WHAT CHANGED

WHAT THEY WOULD TELL SOMEONE ELSE
```

Do not fabricate member testimonials.

Use placeholders clearly labeled until real stories exist.

---

# 24. TRUST

Because people may share uncertainty or work problems, trust must be visible.

Communicate:

```text
NO QUESTION IS TOO BASIC

RESPECT DIFFERENT EXPERIENCE LEVELS

NO UNSOLICITED SELLING

NO PAID PRAISE DISGUISED AS EVIDENCE

DISCLOSE SPONSORSHIP

PRIVACY MATTERS

SHARE ONLY WHAT YOU ARE COMFORTABLE SHARING

DO NOT SHARE CONFIDENTIAL COMPANY INFORMATION

EVIDENCE SOURCES ARE VISIBLE

AI DOES NOT REPLACE HUMAN ACCOUNTABILITY

DO NOT ENCOURAGE EMOTIONAL DEPENDENCE ON AI

HIGH-STAKES ACTIONS NEED APPROPRIATE HUMAN OVERSIGHT

AUTONOMOUS ACTIONS NEED CLEAR PERMISSIONS / LIMITS / STOP CONDITIONS
```

---

# 25. RESEARCH-BACKED DIFFERENTIATION

The visitor should eventually understand:

```text
YOUTUBE
gives me content

AI DIRECTORY
gives me tools

SOCIAL MEDIA
gives me opinions

BENCHMARK
tests models

HUMANITY AI CIRCLE
gives me a place to bring my real AI problem,
learn from other people,
and see increasingly structured evidence
about what actually works.
```

Do not attack other platforms.

Simply make the difference obvious.

---

# 26. BRAND LINES

Use a **line system**, not one sentence forced to carry the entire brand.

### TRANSITION / WHY NOW

# **AI is changing how we work, learn and live.**

### HUMAN / COMMUNITY

# **Don't figure out AI alone.**

### PEOPLE-FIRST BELIEF

# **AI should support people — not replace human connection, judgment or agency.**

### PRACTICAL PRINCIPLE

# **Outcome first. Tool second. Brand last.**

### LEARNING / ARTICULATION

# **Learn to ask AI for the work you actually need.**

### RESPONSIBLE AI

# **Capability does not automatically mean authority.**

### HUMAN CONTROL

# **What should AI help with — and what should stay human?**

### COMMUNITY

# **Real people. Real questions. Real support.**

### EVIDENCE

# **Real people. Real work. Repeated evidence.**

### BELIEF

# **AI is the enabler. People are the ecosystem.**

Use selectively. Do not put all lines on one screen.

Recommended homepage hierarchy:

```text
CONTEXT
AI is changing how we work, learn and live.

HUMAN PROMISE
Don't figure out AI alone.

PRACTICAL PROMISE
Learn • Adapt • Ask • Test • Stay in control.

PRINCIPLE
Outcome first. Tool second. Brand last.
```

---

# 27. COMMUNITY LINKS

Wire these throughout the appropriate pages:

**Community Join Destination — currently WhatsApp**  
`https://chat.whatsapp.com/DsqpygjKEgGHp0yXoh8eLu`

Visible CTA language should normally be **Join the Community**. Use **Continue on WhatsApp** or the WhatsApp icon as supporting destination context.

**YouTube**  
`https://www.youtube.com/@humanityAicircle`

**Instagram**  
`https://www.instagram.com/humanityaicircle/`

**Email**  
`mailto:humanityaicircle@gmail.com`

Use the provided Instagram QR code where helpful.

---

# 28. SOCIAL SHARING

The supplied Humanity AI Circle sharing image is an **Open Graph / WhatsApp preview card**.

It is NOT the webpage design.

Configure:

```html
og:title
og:description
og:image
twitter:card
twitter:title
twitter:description
twitter:image
```

The preview should communicate:

> **Don't figure out AI alone.**

and make someone want to click into the website.

---

# 29. BACKEND / TRACE REQUIREMENT

Retain or implement lightweight, privacy-conscious interaction tracing for:

```text
PAGE VIEW

JOIN COMMUNITY CLICK

WHATSAPP CLICK

YOUTUBE CLICK

INSTAGRAM CLICK

EMAIL CLICK

SOURCE LINK CLICK

WHY-JOIN PATH CLICK

EVIDENCE CARD CLICK

SESSION INTEREST CLICK
```

Do not capture sensitive conversation content, confidential information, or unnecessary personal data.

The trace should help answer:

```text
Which pains resonate most?

Which pages convert?

Which evidence gets opened?

Which CTA drives joins?

Where do visitors abandon?

What does a potential member care about?
```

---

# 30. FINAL INDEPENDENT MEMBER TEST

After implementing the website, review it again from zero.

Pretend you are:

```text
A professional worried about AI

A beginner confused by tools

Someone already using ChatGPT but unsure whether they use it well

Someone with a real AI problem

Someone who hates joining random WhatsApp groups
```

For each persona answer:

```text
What do I understand in 5 seconds?

What catches my attention?

Where do I hesitate?

Do I understand what I get?

Do I trust these people?

Do I understand what happens after joining?

Is there enough evidence?

Is there too much text?

Is navigation obvious?

What would stop me from joining?

Would I click Join?

Why?
```

Fix the site based on those answers.

---

# 31. FINAL BENCHMARK AFTER BUILD

Repeat the scoring after the redesign.

Show:

```text
METRIC                   BEFORE     AFTER
------------------------------------------------
5-second clarity           X/10      X/10
Emotional connection       X/10      X/10
Why join                   X/10      X/10
Pain relevance             X/10      X/10
Trust                      X/10      X/10
Evidence credibility       X/10      X/10
Visual storytelling        X/10      X/10
Navigation                 X/10      X/10
Community authenticity     X/10      X/10
Conversion potential       X/10      X/10
```

Explain exactly what created each improvement.

Do not invent improvement scores without examining the actual before and after builds.

---

# 32. DELIVERY REQUIREMENT

Do not stop at recommendations.

Deliver:

```text
1. CURRENT-BUILD AUDIT
2. BEFORE BENCHMARK
3. INFORMATION ARCHITECTURE
4. UPDATED COPY
5. UPDATED VISUAL SYSTEM
6. COMPLETE MULTI-PAGE WEBSITE
7. WORKING LINKS
8. SOURCE-LINKED RESEARCH
9. SOCIAL-SHARING METADATA
10. PRIVACY-CONSCIOUS TRACES
11. RESPONSIVE QA
12. FINAL INDEPENDENT-JOINER TEST
13. AFTER BENCHMARK
14. ZIP OF COMPLETE FINAL BUILD
15. README WITH DEPLOYMENT / SOCIAL PREVIEW INSTRUCTIONS
```

Do not create a static infographic and call it a website.

Do not replace all content with one generated image.

Do not make every section use pictures of people.

Do not fabricate members, testimonials, community counts, evidence runs, event dates, or outcomes.

Preserve whatever is already good in the latest build.

Improve only where evaluation shows a real reason.

---

# STRATEGIC FLYWHEEL

The site should communicate or support this system over time:

```text
PERSON HAS AN AI PROBLEM
        ↓
ASKS THE COMMUNITY
        ↓
PEOPLE SHARE EXPERIENCE
        ↓
SOMEBODY TRIES A WORKFLOW
        ↓
RESULT IS CAPTURED
        ↓
OTHER PEOPLE REPEAT IT
        ↓
RESULTS ARE COMPARED
        ↓
REPEATED EVIDENCE EMERGES
        ↓
THE NEXT PERSON STARTS BETTER INFORMED
        ↓
TRUST AND CONTRIBUTION INCREASE
        ↺
```

The community is not merely a destination for discussion.

The intended long-term compounding system is:

> **Community → Participation → Real-World Testing → Structured Outcomes → Repeated Evidence → Better Guidance → Better Outcomes → More Trust → More Community**

---

# NORTH STAR

At the end, a first-time visitor should be able to say:

> **“AI is changing the world around me, but I don't have to figure it out alone. I can ask real people, learn how to use AI effectively and responsibly, understand what should stay human, see evidence of what works, and choose my next step with more confidence.”**

And then:

# **“I want to join.”**

---

# FINAL STRATEGIC TEST

The finished website must succeed at both of these levels:

### TODAY
A visitor thinks:

> **“I have somewhere useful to go while I learn how AI is changing my work and life — and I can learn with people rather than alone.”**

### AS I LEARN
A member understands:

> **“AI should support my goals. I still own the judgment, relationships, boundaries and consequences.”**

### OVER TIME
A returning member understands:

> **“This community is building increasingly useful evidence about what actually works for people using AI in real contexts — including where AI should stop and humans should remain in control.”**

If the website achieves only the first, it risks becoming a generic support community.

If it achieves only the second, it risks becoming an abstract research product.

Humanity AI Circle should combine both.


---

# V4 — NEW SCOPE ADDED

V4 preserves V3 and adds the following scope:

1. **AI transition story** — PC → Internet → Mobile/Cloud → AI → You.
2. **Global framing beyond work** — work, learning and everyday life.
3. **People-first / human-agency principle** — AI supports people; it does not replace human connection, judgment or responsibility.
4. **AI companion principle** — AI may assist/augment human capability, but Humanity AI Circle remains a people-to-people community and must not encourage emotional dependency on AI.
5. **Transition readiness** — upskilling, mindset change, overcoming fear, learning and adaptation.
6. **Outcome-first philosophy** — outcome first, tool second, brand last.
7. **Task articulation** — durable skill beyond prompt engineering.
8. **Efficient AI use** — less repeated prompting, unnecessary context, tool switching, rework and token/cost waste.
9. **Independent tool/workflow comparison** — test comparable approaches and publish contextual findings rather than generic winners.
10. **Global curiosity architecture** — jobs, learning, trust, human identity/relationships, autonomy/control.
11. **Loneliness and human connection** — ask when AI is useful and when another person is needed.
12. **AI dependence** — use AI without outsourcing independent thinking and judgment.
13. **Trust and responsible AI** — accuracy, privacy, safety, provenance and accountability.
14. **Human control** — human ownership of consequential goals, approvals and outcomes.
15. **Autonomous AI boundaries** — permissions, access, spending, action limits, approvals, stop conditions and human override.
16. **AI Transition Pulse** — current news/data translated into practical human questions rather than fear-driven news.
17. **Founder/origin credibility** — experienced technology/transformation/AI practitioners created the community after seeing the gap between tool access and effective outcomes.
18. **Expanded benchmark** — explicitly score transition relevance, human agency, outcome-first clarity, articulation, efficiency, responsible AI, autonomy boundaries, global curiosity coverage and founder credibility.

V4 does **not** change the core strategic architecture:

```text
PEOPLE
↓
REAL QUESTIONS / PROBLEMS
↓
CONNECTION + LEARNING
↓
PRACTICAL AI USE
↓
HUMAN JUDGMENT + CONTROL
↓
TESTED OUTCOMES
↓
REPEATED EVIDENCE
↓
BETTER HUMAN DECISIONS
```

The core belief is:

# **AI should be in service of people — not people in service of AI.**

And the community remains:

# **People helping people learn how to live and work well with AI.**
