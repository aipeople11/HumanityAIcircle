# V12 CHANGELOG — WHAT WAS CONSOLIDATED

V12 is a consolidation release, not another thesis expansion.

## Preserved from earlier builds
- Warm grid-paper visual language, bold borders, rounded cards and offset shadows.
- Hero community illustration as a supporting visual asset rather than a screenshot of the website.
- “Don't figure out AI alone.” emotional promise.
- Source-linked research cards.
- Evidence maturity model.
- Social icons and working community links.

## Added / corrected in V12
1. AI transition story: PC → Internet → Mobile/Cloud → AI → You.
2. Global scope: work, learning, life, trust, humanity and control.
3. People-connect model: question ↔ experience, idea ↔ builder, problem ↔ domain knowledge, workflow ↔ tester.
4. Outcome-first AI use: outcome → articulation → tool/workflow → validation → improvement.
5. Task articulation as a durable skill beyond prompt engineering.
6. Efficiency framing: less rework, repeated prompting, tool switching and unnecessary token/cost burn.
7. Human-agency principle: People lead. AI helps.
8. Responsible AI and autonomy boundaries: permissions, approvals, stop conditions and human override.
9. Global curiosity paths: jobs, skills, productivity, learning, trust, control, humanity.
10. Weekly 30 as the community heartbeat every weekend.
11. Founder/origin explanation.
12. Technical completeness: shared CSS, shared JS, mobile nav, optional dependency-free trace server, legacy redirects.

## Scope intentionally not added
- Generic AI directory
- Generic AI news feed
- Jobs marketplace
- Formal mentor marketplace
- Large course platform
- Prompt library as a product
- Dozens of empty subcommunities
