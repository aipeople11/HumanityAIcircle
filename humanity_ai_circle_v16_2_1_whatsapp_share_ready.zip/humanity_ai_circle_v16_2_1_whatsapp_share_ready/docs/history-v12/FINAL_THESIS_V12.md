# Humanity AI Circle — V12 Thesis Lock

## Core thesis

**Humanity AI Circle is a people-first community helping people move through the AI transition together.**

People come to learn, ask, adapt, connect, experiment, build, validate and share — while keeping human judgment, connection, responsibility and control at the center.

## Core belief

**People lead. AI helps.**

AI can be a companion to human capability, but it is not a substitute for human connection, judgment, responsibility or agency.

## Brand system

- Context: **AI is changing how we work, learn and live.**
- Human promise: **Don't figure it out alone.**
- Invitation: **Bring your question. Bring your idea. Bring what you know.**
- Practical philosophy: **Outcome first. Tool second. Brand last.**
- Responsible-use principle: **Use AI without giving away human judgment.**
- Community action: **Ask. Learn. Adapt. Build. Test. Share.**
- Evidence line: **Real people. Real work. Repeated evidence.**

## Community heartbeat

**Weekly 30** — one useful conversation every weekend. Exact timing is announced in the community.

Formats include real AI problems, workflow tests, idea exchanges, build-together discussions, AI & My Job, and What Should Stay Human?

## Scope control

New ideas belong only if they help people:

1. connect with other people,
2. adapt to the AI transition,
3. use AI more effectively and responsibly,
4. protect human judgment and control, or
5. turn shared learning into something useful or evidence-based.

Do not expand the core proposition into a generic AI directory, news portal, jobs marketplace, course platform, mentor marketplace or prompt library unless real community behavior later proves the need.
