# V13 changes from V12

- Restored **Don’t Figure Out AI Alone** as the primary conversion headline while keeping the AI-transition context.
- Added **Where are you in this transition?** life-stage entry points.
- Added **Explore** as a top-level channel instead of overcrowding the primary navigation.
- Added dedicated **Themes**, **People**, **What’s happening now**, and **Roadmap** pages.
- Added a shared story strip: Transition → My question → People → Practice → Evidence → Progress.
- Added contextual story sections across Why Join, How It Works, Community, Evidence, Research, About, Sessions and Stories.
- Added transparent status language distinguishing live, defined, starting, next and future.
- Kept research source-linked and avoided fabricated community counts, testimonials, event dates or evidence results.
- Kept Weekly 30 as the operating heartbeat.
- Preserved people-first, outcome-first, responsible-AI and evidence principles.
