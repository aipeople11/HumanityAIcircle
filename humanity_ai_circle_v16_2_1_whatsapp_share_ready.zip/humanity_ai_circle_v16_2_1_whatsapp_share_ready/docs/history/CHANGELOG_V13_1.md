# V13.1 changelog

## Fixed
1. Hero CTA `Explore the Circle` incorrectly pushed first-time visitors into an internal-feeling exploration hub. It now says `See How It Works` and opens `how-it-works.html`.
2. `explore.html` used internal copy such as `The homepage is the front door`; replaced with visitor-facing exploration language.
3. Replaced `Connect the story / Transition / My question / People / Practice / Evidence / Progress` with question-led navigation.
4. Removed internal thesis/product language from About, Now, Roadmap, Stories and Research.
5. Preserved V13 thesis, design system, social links, evidence model and community architecture.
