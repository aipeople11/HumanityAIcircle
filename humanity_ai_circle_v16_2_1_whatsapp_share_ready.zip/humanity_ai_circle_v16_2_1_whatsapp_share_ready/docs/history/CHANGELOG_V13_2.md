# Humanity AI Circle V13.2 — Conversion + Evidence Restoration

This correction restores high-conversion homepage sections that were present in earlier builds and should not have been removed during V13 simplification.

## Restored / added on the homepage

- You may be here because...
- What you get from joining
- Ask → Connect → Learn → Try → Build → Share
- Global signals with 58% / 52% / 74% / 18% source-linked cards
- From hype to evidence
- Different people, one shared transition
- Sample evidence card + evidence maturity
- Use ≠ confidence ≠ measured value micro-graphs
- How community activity creates evidence
- What should stay human?
- Real questions people can bring
- Join-channel cards for WhatsApp, YouTube, Instagram and email
- Instagram QR strip

## What remains from V13/V13.1

- AI transition framing
- V13 people-stage paths
- people-connect model
- outcome-first / task-articulation flow
- Explore hub and deeper subpages
- Weekly 30 / activity model
- People lead. AI helps.

The homepage now combines the strongest conversion elements of V9/V11 with the broader V13 thesis and evidence model.
