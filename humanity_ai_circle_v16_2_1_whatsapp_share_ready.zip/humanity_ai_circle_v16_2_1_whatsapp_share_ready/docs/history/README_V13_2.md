# Humanity AI Circle V13.2

V13.2 restores the conversion and evidence sections that were over-trimmed in V13 while preserving the V13 thesis and deeper exploration pages.

## Start

Open `index.html` directly for the static site, or run:

```bash
node server.js
```

## Primary journey

Hero → Transition → Pain recognition → Member value → Community loop → Life stage → People connection → Outcome-first AI → Global signals → Hype-to-evidence → Roles → Evidence preview → Community activity → Human-first principles → Real questions → Explore → Join channels → Final CTA.
